﻿using System.Collections.Generic;

namespace ChineseChess
{
    public class Board
    {
        private readonly int row = 10;
        private readonly int col = 9;
        private int turnRoundNums;
        private string turnRound;
        private readonly Chess[,] board;
        private int FirstInput_row;
        private int FirstInput_col;
        private int SecondInput_row;
        private int SecondInput_col;

        public Board()
        {
            this.turnRoundNums = 0;
            this.turnRound = "Red";

            this.board = new Chess[this.row, this.col];
            initializeBoard();
        }

        private void initializeBoard()
        {
            //-----------初始化棋盘
            for (int row = 0; row < this.row; row++)
            {
                for (int col = 0; col < this.col; col++)
                {
                    if (row == 0 || (row == this.row - 1))
                    {
                        //车马象仕帅
                        this.board[row, col] = col switch
                        {
                            0 => (row < this.row / 2) ? new Car("Black") : new Car("Red"),
                            8 => (row < this.row / 2) ? new Car("Black") : new Car("Red"),
                            1 => (row < this.row / 2) ? new Horse("Black") : new Horse("Red"),
                            7 => (row < this.row / 2) ? new Horse("Black") : new Horse("Red"),
                            2 => (row < this.row / 2) ? new Elephant("Black") : new Elephant("Red"),
                            6 => (row < this.row / 2) ? new Elephant("Black") : new Elephant("Red"),
                            3 => (row < this.row / 2) ? new Samurai("Black") : new Samurai("Red"),
                            5 => (row < this.row / 2) ? new Samurai("Black") : new Samurai("Red"),
                            4 => (row < this.row / 2) ? new General("Black") : new General("Red"),
                            _ => new Blank("White")
                        };
                    }
                    else if ((row == 2 || (row == this.row - 3)) && (col == 1 || col == 7))
                    {
                        //炮
                        this.board[row, col] = (row < this.row / 2) ? new Cannon("Black") : new Cannon("Red");
                    }
                    else if ((row == 3 || (row == this.row - 4)) && (col % 2 == 0))
                    {
                        //卒
                        this.board[row, col] = (row < this.row / 2) ? new Soldier("Black") : new Soldier("Red");
                    }
                    else
                    {
                        this.board[row, col] = new Blank("White");
                    }
                }
            }
        }

        public dynamic GetChess(int row, int col)
        {
            return this.board[row, col];
        }

        public void SetChess(int row, int col, dynamic chess)
        {
            this.board[row, col] = chess;
        }

        public Chess[,] GetBoard()
        {
            return this.board;
        }

        public int GetTurnRoundNums()
        {
            return this.turnRoundNums;
        }

        public void SetTurnRoundNums(int num)
        {
            SetTurnRound((GetTurnRoundNums() % 2 == 0) ? "Red" : "Black");
            this.turnRoundNums += num;
        }

        public void SetTurnRound(string turnRound)
        {
            this.turnRound = turnRound;
        }

        public string GetTurnRound()
        {
            return this.turnRound;
        }

        public int[] GetFirstInput()
        {
            return new int[] { this.FirstInput_row, this.FirstInput_col };
        }

        public int[] GetSecondInput()
        {
            return new int[] { this.SecondInput_row, this.SecondInput_col };
        }

        public void SetFirstInput(int[] nums)
        {
            this.FirstInput_row = nums[0];
            this.FirstInput_col = nums[1];
        }

        public void SetSecondInput(int[] nums)
        {
            this.SecondInput_row = nums[0];
            this.SecondInput_col = nums[1];
        }

        public void Restart()
        {
            this.turnRoundNums = 0;
            this.turnRound = "Red";
            initializeBoard();
        }
    }

    public class Chess
    {
        protected string color;
        protected readonly string defaultColor;

        /// <summary>
        /// 存储棋子可以移动的点
        /// </summary>
        public List<int[]> possibleMovePointList = new List<int[]> { };

        public Chess(string color)
        {
            this.defaultColor = color;
            this.color = color;
        }

        public Chess()
        {
        }

        /// <summary>
        /// Check the next point of the selected chess can move or not and show it in Blue color.
        /// </summary>
        /// <param name="chess">The next point of the selected point.</param>

        public void SetColor(string color)
        {
            this.color = color;
        }

        public string GetColor()
        {
            return this.color;
        }

        public string GetDefaultColor()
        {
            return this.defaultColor;
        }

        public virtual string GetName()
        {
            return " ";
        }

        /// <summary>
        /// Find all the point that the selected chess can move can show it in blue.
        /// </sum mary>
        /// <param name="row">the horizontal coordinate of the piece in the board </param>
        /// <param name="col">the vertical coordinate of the piece in the board</param>
        public virtual void PossibleMove(int row, int col, Board board) { }
    }

    public class Car : Chess
    {
        public new List<int[]> possibleMovePointList = new List<int[]> { };

        public Car()
        {
        }

        public Car(string color)
        : base(color)
        {
        }

        public override string GetName()
        {
            return "车";
        }

        public override void PossibleMove(int row, int col, Board board)
        {
            this.possibleMovePointList.Clear();
            bool[] direction = new bool[4] { true, true, true, true };

            for (int i = 0; i < 10; i++)
            {
                if (row - i >= 0 && direction[0])
                {
                    direction[0] = Judge(row, col, row - i, col, board);
                }
                if (row + i <= 9 && direction[1])
                {
                    direction[1] = Judge(row, col, row + i, col, board);
                }
                if (col - i >= 0 && direction[2])
                {
                    direction[2] = Judge(row, col, row, col - i, board);
                }
                if (col + i <= 8 && direction[3])
                {
                    direction[3] = Judge(row, col, row, col + i, board);
                }
            }

            bool Judge(int row, int column, int validRow, int validColumn, Board board)
            {
                if (row == validRow && column == validColumn)
                {
                    return true;
                }
                int[] temp = new int[2];
                dynamic tempObject = board.GetChess(validRow, validColumn);
                if (tempObject.GetColor().Equals("White") || !tempObject.GetColor().Equals("White") && this.GetColor() != tempObject.GetColor())
                {
                    temp[0] = validRow;
                    temp[1] = validColumn;
                    this.possibleMovePointList.Add(temp);
                    if (tempObject.GetColor().Equals("White"))
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
                else
                {
                    return false;
                }
            }
        }
    }

    public class Horse : Chess
    {
        public new List<int[]> possibleMovePointList = new List<int[]> { };

        public Horse()
        {
        }

        public Horse(string color)
        : base(color)
        {
        }

        public override string GetName()
        {
            return "马";
        }

        public override void PossibleMove(int row, int col, Board board)
        {
            void ChangeList(int row, int col)
            {
                if (!board.GetChess(row, col).GetColor().Equals(this.GetColor()))
                {
                    possibleMovePointList.Add(new int[] { row, col });
                }
            }
            for (int i = 0; i < board.GetBoard().GetLength(0); i++)
            {
                for (int j = 0; j < board.GetBoard().GetLength(1); j++)
                {
                    if (((System.Math.Abs(i - row) == 1 && j == col) || (i == row && System.Math.Abs(j - col) == 1)) && board.GetChess(i, j).GetColor().Equals("White"))
                    {
                        if ((i < row && i != 0))
                        {
                            if (j != board.GetBoard().GetLength(1) - 1)
                            {
                                ChangeList(i - 1, j + 1);
                            }

                            if (j != 0)
                            {
                                ChangeList(i - 1, j - 1);
                            }
                        }
                        else if (i > row && i != board.GetBoard().GetLength(0) - 1)
                        {
                            if (j != board.GetBoard().GetLength(1) - 1)
                            {
                                ChangeList(i + 1, j + 1);
                            }

                            if (j != 0)
                            {
                                ChangeList(i + 1, j - 1);
                            }
                        }
                        if (j < col && j != 0)
                        {
                            if (i != board.GetBoard().GetLength(0) - 1)
                            {
                                ChangeList(i + 1, j - 1);
                            }

                            if (i != 0)
                            {
                                ChangeList(i - 1, j - 1);
                            }
                        }
                        else if (j > col && j != board.GetBoard().GetLength(1) - 1)
                        {
                            if (i != board.GetBoard().GetLength(0) - 1)
                            {
                                ChangeList(i + 1, j + 1);
                            }

                            if (i != 0)
                            {
                                ChangeList(i - 1, j + 1);
                            }
                        }
                    }
                }
            }
        }
    }

    public class Elephant : Chess
    {
        public new List<int[]> possibleMovePointList = new List<int[]> { };

        public Elephant()
        {
        }

        public Elephant(string color)
        : base(color)
        { }

        public override string GetName()
        {
            return "象";
        }

        public override void PossibleMove(int row, int col, Board board)
        {
            void ChangeList(int row, int col)
            {
                if (!board.GetChess(row, col).GetColor().Equals(this.GetColor()))
                {
                    possibleMovePointList.Add(new int[] { row, col });
                }
            }
            int interval = GetColor().Equals("Black") ? board.GetBoard().GetLength(0) / 2 : board.GetBoard().GetLength(0);
            int startNum = GetColor().Equals("Black") ? 0 : board.GetBoard().GetLength(0) / 2;
            for (int i = startNum; i < interval; i++)
            {
                for (int j = 0; j < board.GetBoard().GetLength(1); j++)
                {
                    if ((System.Math.Abs(i - row) == 1) && (System.Math.Abs(j - col) == 1) && board.GetChess(i, j).GetColor().Equals("White"))
                    {
                        if (i < row && j < col)
                        {
                            ChangeList(i - 1, j - 1);
                        }
                        if (i < row && j > col)
                        {
                            ChangeList(i - 1, j + 1);
                        }
                        if (i > row && j < col)
                        {
                            ChangeList(i + 1, j - 1);
                        }
                        if (i > row && j > col)
                        {
                            ChangeList(i + 1, j + 1);
                        }
                    }
                }
            }
        }
    }

    public class Samurai : Chess
    {
        public new List<int[]> possibleMovePointList = new List<int[]> { };

        public Samurai()
        {
        }

        public Samurai(string color)
        : base(color)
        {
        }

        public override string GetName()
        {
            return "士";
        }

        public override void PossibleMove(int row, int col, Board board)
        {
            int startNum = GetColor().Equals("Black") ? 0 : 7;
            for (int i = startNum; i < startNum + 3; i++)
            {
                for (int j = 3; j < 6; j++)
                {
                    if ((System.Math.Abs(i - row) == 1) && (System.Math.Abs(j - col) == 1) && !board.GetChess(i, j).GetColor().Equals(this.GetColor()))
                    {
                        if (!board.GetChess(i, j).GetColor().Equals(this.GetColor()))
                        {
                            possibleMovePointList.Add(new int[] { i, j });
                        }
                    }
                }
            }
        }
    }

    public class General : Chess
    {
        public new List<int[]> possibleMovePointList = new List<int[]> { };

        public General()
        {
        }

        public General(string color)
        : base(color)
        {
        }

        public override string GetName()
        {
            return this.GetDefaultColor().Equals("Red") ? "帅" : "将";
        }

        //先判断颜色方 然后判断根据移动方式给出的点是否可行
        public override void PossibleMove(int row, int col, Board board)
        {
            int startNum = GetColor().Equals("Black") ? 0 : 7;
            for (int i = startNum; i < startNum + 3; i++)
            {
                for (int j = 3; j < 6; j++)
                {
                    if (((System.Math.Abs(i - row) == 1 && j == col) || (i == row && System.Math.Abs(j - col) == 1)) && !board.GetChess(i, j).GetColor().Equals(this.GetColor()))
                    {
                        possibleMovePointList.Add(new int[] { i, j });
                    }
                }
            }
            if (GetColor().Equals("Black"))
            {
                for (int i = row + 1; i < 10; i++)
                {
                    if (!board.GetChess(i, col).GetColor().Equals("White"))
                    {
                        if (board.GetChess(i, col).GetName().Equals("帅"))
                        {
                            possibleMovePointList.Add(new int[] { i, col });
                        }
                        else break;
                    }
                }
            }
            if (GetColor().Equals("Red"))
            {
                for (int i = row - 1; i >= 0; i--)
                {
                    if (!board.GetChess(i, col).GetColor().Equals("White"))
                    {
                        if (board.GetChess(i, col).GetName().Equals("将"))
                        {
                            possibleMovePointList.Add(new int[] { i, col });
                        }
                        else break;
                    }
                }
            }
        }
    }

    public class Cannon : Chess
    {
        public new List<int[]> possibleMovePointList = new List<int[]> { };

        public Cannon()
        {
        }

        public Cannon(string color)
        : base(color)
        {
        }

        public override string GetName()
        {
            return "炮";
        }

        public override void PossibleMove(int row, int col, Board board)
        {
            dynamic chess;
            string color = this.GetColor();
            bool haveMiddleChess = false;

            bool Moving(int row, int col)
            {
                //判断是否是能吃的敌方棋子 是的话将其设为蓝色
                if ((haveMiddleChess == true) && (!(chess.GetColor().Equals("White"))))
                {
                    if (!(chess.GetColor().Equals(color)))
                    {
                        possibleMovePointList.Add(new int[] { row, col });
                    }

                    return true;
                }
                //判断是否为空格，否则将'有中间棋子'设为true
                if (chess.GetColor().Equals("White") && (haveMiddleChess != true))
                {
                    possibleMovePointList.Add(new int[] { row, col });
                    return false;
                }
                else
                {
                    haveMiddleChess = true;
                    return false;
                }
            }
            void Process(int temp)
            {
                int i = temp switch
                {
                    0 => row - 1,
                    1 => col - 1,
                    _ => 0,
                };
                int j = temp switch
                {
                    0 => row - 1,
                    1 => col - 1,
                    _ => 0
                };
                int x = temp switch
                {
                    0 => row,
                    1 => col,
                    _ => 0
                };
                bool moving = false;
                while (j > x - board.GetBoard().GetLength(0) - temp && i < 10 - temp)
                {
                    if (x == 0)
                    {
                        i = x + System.Math.Abs(j);
                    }

                    switch (temp)
                    {
                        case 0:
                            chess = board.GetChess(i, col);
                            moving = Moving(i, col);
                            break;

                        case 1:
                            chess = board.GetChess(row, i);
                            moving = Moving(row, i);
                            break;
                    }

                    if (moving)
                    {
                        if (i >= 0 && j >= 0)
                        {
                            haveMiddleChess = false;
                            j = -1;
                            i = x + System.Math.Abs(j);
                            continue;
                        }
                        else
                        {
                            j = 0 - board.GetBoard().GetLength(0) - temp;
                        }
                    }
                    else
                    {
                        if (j == 0)
                            haveMiddleChess = false;
                        j--;
                        if (j >= 0)
                        {
                            i = j;
                        }
                        else
                        {
                            i = x + System.Math.Abs(j);
                        }
                    }
                }
            }

            for (int i = 0; i < 2; i++)
            {
                haveMiddleChess = false;
                Process(i);
            }
        }
    }

    public class Soldier : Chess
    {
        public new List<int[]> possibleMovePointList = new List<int[]> { };

        public Soldier()
        {
        }

        public Soldier(string color)
        : base(color)
        {
        }

        public override string GetName()
        {
            return this.GetDefaultColor().Equals("Red") ? "兵" : "卒";
        }

        public override void PossibleMove(int row, int col, Board board)
        {
            void ChangeList(int row, int col)
            {
                if (row >= 0 && row < board.GetBoard().GetLength(0) && col >= 0 && col < board.GetBoard().GetLength(1))
                {
                    if (!this.GetColor().Equals(board.GetChess(row, col).GetColor()))
                    {
                        possibleMovePointList.Add(new int[] { row, col });
                    }
                }
            }
            //先判断颜色方 然后判断根据移动方式给出的点是否可行
            switch (this.GetColor())
            {
                case "Red":
                    if (row >= (board.GetBoard().GetLength(0) / 2) && (!this.GetColor().Equals(board.GetChess(row - 1, col).GetColor())))
                    {
                        possibleMovePointList.Add(new int[] { row - 1, col });
                    }
                    else
                    {
                        ChangeList(row - 1, col);
                        ChangeList(row, col - 1);
                        ChangeList(row, col + 1);
                    }
                    break;

                case "Black":
                    if (row < (board.GetBoard().GetLength(0) / 2) && (!this.GetColor().Equals(board.GetChess(row + 1, col).GetColor())))
                    {
                        possibleMovePointList.Add(new int[] { row + 1, col });
                    }
                    else
                    {
                        ChangeList(row + 1, col);
                        ChangeList(row, col - 1);
                        ChangeList(row, col + 1);
                    }
                    break;
            }
        }
    }

    public class Blank : Chess
    {
        private string name = "┼─";

        public Blank()
        {
        }

        public Blank(string color)
        : base(color)
        {
        }

        public override string GetName()
        {
            return this.name;
        }

        public void SetName(string name)
        {
            this.name = name;
        }
    }
}