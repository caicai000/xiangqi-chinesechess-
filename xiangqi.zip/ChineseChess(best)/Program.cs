﻿using System;

namespace ChineseChess
{
    /// <summary>
    /// 不要用static变量 把输入点存入BOARD中
    /// </summary>
    internal class Program
    {
        private static void Main()
        {
            bool gameOver = false;
            Board board = new Board();
            View view = new View(board);

            while (!gameOver)
            {
                do
                {
                    try
                    {
                        //第一次选择
                        //展示棋盘
                        view.DisplayBoard();
                        //递增回合数
                        Controller.ChangeTurnRoundNums(board, 1);

                        Controller.Var.temp = board.GetTurnRoundNums();
                        string strInput = view.ShowTips1();
                        //要求用户输入选择棋子的坐标
                        if (strInput.Equals("Give up"))
                            gameOver = true;
                        else if (strInput.Equals("Regret"))
                            continue;
                        else if (strInput.Equals("Restart"))
                            continue;
                        else if (Controller.ChooseATurnRoundColorChess(board, "firstInput"))
                        {
                            //显示棋子能走的方位
                            Controller.SetThePosiibleMovePointList(board, "firstInput");

                            view.DisplayBoard();

                            break;
                        }
                        else
                        {
                            Controller.ChangeTurnRoundNums(board, -1);
                            continue;
                        }
                    }
                    catch (Exception)
                    {
                        //防止输入格式有误直接导致程序停止
                        Controller.ChangeTurnRoundNums(board, -1);
                        continue;
                    }
                } while (true);

                //第二次选择
                do
                {
                    try
                    {
                        //要求用户输入坐标
                        view.ShowTips2();

                        //检测输入的坐标是否为可选方位
                        if (Controller.ChooseBluePoints(board))
                        {
                            //检测将要被吃的棋子是否为’将/帅‘
                            gameOver = Controller.TheGeneralIsGongingToBeAte(board);
                            //移动棋子
                            Controller.MoveTheChess(board);
                            break;
                        }
                        //如果输入的不是蓝色点位 而是其它同色棋子 表明用户重新选择
                        else if (Controller.ChooseATurnRoundColorChess(board, "secondInput"))
                        {
                            //根据用户输入展示新的蓝色点
                            Controller.SetThePosiibleMovePointList(board, "secondInput");

                            view.DisplayBoard();
                            Controller.ExchangeTwoChoose(board);
                            continue;
                        }
                        else
                        {
                            view.DisplayBoard();
                            view.ShowTips3();
                            continue;
                        }
                    }
                    catch (Exception)
                    {
                        view.DisplayBoard();
                    }
                } while (true);
            }

            view.GameOver();
        }
    }
}