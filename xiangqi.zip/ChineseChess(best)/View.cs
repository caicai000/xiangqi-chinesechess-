﻿using System;

namespace ChineseChess
{
    public class View
    {
        private readonly Board board;

        public View(Board board)
        {
            this.board = board;
        }

        /// <summary>
        /// Show the chessboard to the user.
        /// </summary>
        public void DisplayBoard()
        {
            Console.Clear();

            dynamic chess;
            int row;
            int col;
            for (int x = 0; x < 20; x++)
            {
                for (int y = 0; y < 18; y++)
                {
                    Console.BackgroundColor = ConsoleColor.DarkYellow;
                    Console.ForegroundColor = ConsoleColor.Magenta;

                    //坐标提示
                    if (x == 0 && y == 0)
                    {
                        Console.Write("  ");
                        continue;
                    }
                    if (x == 0)
                    {
                        if (y % 2 != 0)
                            Console.Write($"{y / 2} ");
                        else
                            Console.Write("  ");
                        continue;
                    }
                    if (y == 0)
                    {
                        if (x % 2 != 0)
                            Console.Write($"{x / 2} ");
                        else
                            Console.Write("  ");
                        continue;
                    }

                    if ((x % 2 == 1) && (y % 2 == 1))
                    {
                        row = x / 2;
                        col = y / 2;
                        chess = this.board.GetChess(row, col);
                    }
                    else
                        chess = new Blank("White");

                    SetChessForegroundColor(chess.GetColor());

                    //根据空白的位置设置形状
                    if (chess.GetDefaultColor().Equals("White"))
                    {
                        //特殊点位
                        if (x == 10)
                        {
                            switch (y)
                            {
                                case 1:
                                case 17:
                                    chess.SetName("│ ");
                                    break;

                                case 3:
                                    chess.SetName("楚");
                                    break;

                                case 5:
                                    chess.SetName("河");
                                    break;

                                case 13:
                                    chess.SetName("汉");
                                    break;

                                case 15:
                                    chess.SetName("界");
                                    break;

                                default:
                                    chess.SetName("  ");
                                    break;
                            }
                        }
                        else if (x % 2 - 1 != 0 && y % 2 - 1 != 0)
                        {
                            chess.SetName("  ");
                        }
                        else if (x % 2 - 1 == 0 && y % 2 - 1 != 0)
                        {
                            chess.SetName("──");
                        }
                        else if (x % 2 - 1 != 0 && y % 2 - 1 == 0)
                        {
                            chess.SetName("│ ");
                        }
                        else if (y == 1)
                        {
                            //第一列
                            if (x == 1)
                            {
                                chess.SetName("┌─");
                            }
                            else if (x == 19)
                            {
                                chess.SetName("└ ");
                            }
                            else if (x != 10)
                                chess.SetName("├─");
                        }
                        else if (y == 17)
                        {
                            //最后一列
                            if (x == 1)
                                chess.SetName("┐ ");
                            else if (x == 20 - 1)
                                chess.SetName("┘ ");
                            else if (x != 20 / 2)
                                chess.SetName("┤ ");
                        }
                        else if (y != 0 || (y != 18 - 1))
                        {
                            //楚河汉界上下边
                            if ((x == 20 / 2 - 1) || (x == 19))
                                chess.SetName("┴─");
                            else if (x == 1 || (x == 11))
                                chess.SetName("┬─");
                        }
                        //九宫格
                        if ((y == 8))
                        {
                            if (x == 4 || x == 18)
                            {
                                chess.SetName("╱ ");
                            }
                            if (x == 2 || x == 16)
                            {
                                chess.SetName("╲ ");
                            }
                        }
                        else if (y == 10)
                        {
                            if (x == 2 || x == 16)
                            {
                                chess.SetName("╱ ");
                            }
                            else if (x == 4 || x == 18)
                            {
                                chess.SetName("╲ ");
                            }
                        }
                    }
                    else
                    {
                        Console.BackgroundColor = ConsoleColor.Gray;
                    }

                    Console.Write(chess.GetName());
                    Console.ResetColor();
                }
                Console.WriteLine();
            }
            Console.WriteLine();
            if (Controller.IsValid(board))
            {
                Console.WriteLine("                将军！");
                Console.WriteLine();
            }

            Console.Write("====================================\n" +
                              "    Restart || Regret || Give up    \n" +
                              "====================================\n");
        }

        public string ShowTips1()
        {
            //弹出提示语
            Console.WriteLine("\nInput which one " + this.board.GetTurnRound() + " chess you choose.(row col):");
            string strInput = Console.ReadLine();
            if (strInput.Equals("Give up"))
            {
            }
            if (strInput.Equals("Regret"))
            {
                if (!Controller.JudeBack(board) && Controller.Var.reallyMove)
                {
                    Controller.Back(board);
                }
                else
                {
                    Console.WriteLine("Please using regret after you move");
                }
            }
            if (strInput.Equals("Restart"))
            {
                Controller.Restart(board);
            }
            else
            {
                this.board.SetFirstInput(ConvertIndex(strInput));
            }
            return strInput;
        }

        public void ShowTips2()
        {
            //弹出提示语
            Console.WriteLine("\nWhich blue point you want to move?(row col)" +
                                    " or you can choose another " + this.board.GetTurnRound() + " chess.");
            this.board.SetSecondInput(ConvertIndex(Console.ReadLine()));
        }

        public void ShowTips3()
        {
            //弹出提示语
            Console.WriteLine("\n  You should choose a blue point OR choose another " + this.board.GetTurnRound() + " chess.");
        }

        public void GameOver()
        {
            Console.WriteLine("\n\n\t\t\t\tGAME OVAER!!!!!!");
        }

        public int[] ConvertIndex(string strInput)
        {
            int[] coordinate = new int[2];
            coordinate[0] = Convert.ToInt32((strInput.Split(' '))[0]);
            coordinate[1] = Convert.ToInt32((strInput.Split(' '))[1]);
            return coordinate;
        }

        public static void SetChessForegroundColor(string color)
        {
            //设置单元格字体颜色
            Console.ForegroundColor = color switch
            {
                "Red" => ConsoleColor.Red,
                "Black" => ConsoleColor.Black,
                "Blue" => ConsoleColor.Blue,
                _ => ConsoleColor.White,
            };
        }
    }
}