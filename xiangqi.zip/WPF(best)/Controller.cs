﻿using System.Collections.Generic;

namespace ChineseChess
{
    public class Controller
    {
        public static void ResetBoardToDefaultColor(Board board)
        {
            //将整体棋盘恢复默认配色
            foreach (Chess c in board.GetBoard())
            {
                if (c.GetColor().Equals("Blue"))
                {
                    c.SetColor(c.GetDefaultColor());
                }
            }
        }

        /// <summary>
        /// 将可移动的点颜色改成蓝色
        /// </summary>
        /// <param name="row"></param>
        /// <param name="col"></param>
        public static void SetThePosiibleMovePointList(Board board, string str)
        {
            ResetBoardToDefaultColor(board);
            dynamic chess;
            if (str.Equals("firstInput"))
                chess = board.GetChess(board.GetFirstInput()[0], board.GetFirstInput()[1]);
            else
                chess = board.GetChess(board.GetSecondInput()[0], board.GetSecondInput()[1]);
            chess.possibleMovePointList.Clear();
            chess.PossibleMove(board.GetFirstInput()[0], board.GetFirstInput()[1], board);

            List<int[]> list = chess.possibleMovePointList;
            foreach (int[] index in list)
            {
                board.GetChess(index[0], index[1]).SetColor("Blue");
            }
        }

        public static bool ChooseATurnRoundColorChess(Board board, string str)
        {
            if (str.Equals("firstInput"))
                return board.GetChess(board.GetFirstInput()[0], board.GetFirstInput()[1]).GetColor().Equals(board.GetTurnRound());
            return board.GetChess(board.GetSecondInput()[0], board.GetSecondInput()[1]).GetColor().Equals(board.GetTurnRound());
        }

        public static bool TheGeneralIsGongingToBeAte(Board board)
        {
            return (board.GetChess(board.GetSecondInput()[0], board.GetSecondInput()[1]).GetName().Equals("将")
                        || board.GetChess(board.GetSecondInput()[0], board.GetSecondInput()[1]).GetName().Equals("帅"));
        }

        public static void ChangeTurnRoundNums(Board board, int num)
        {
            board.SetTurnRoundNums(num);
        }

        public static bool ChooseBluePoints(Board board)
        {
            return board.GetChess(board.GetSecondInput()[0], board.GetSecondInput()[1]).GetColor().Equals("Blue");
        }

        public static void ExchangeTwoChoose(Board board)
        {
            board.SetFirstInput(new int[] { board.GetSecondInput()[0], board.GetSecondInput()[1] });
        }

        public static void Restart(Board board)
        {
            board.Restart();
        }

        public static bool IsValid(Board board)
        {
            List<int[]> list;
            for (int i = 0; i < 10; i++)
            {
                for (int j = 0; j < 9; j++)
                {
                    board.GetChess(i, j).PossibleMove(i, j, board);
                    list = board.GetChess(i, j).possibleMovePointList;
                    foreach (int[] index in list)
                    {
                        if ((board.GetChess(index[0], index[1]).GetName() == "将" && board.GetChess(i, j).GetDefaultColor().Equals("Red")) || (board.GetChess(index[0], index[1]).GetName() == "帅") && board.GetChess(i, j).GetDefaultColor().Equals("Black"))
                        {
                            list.Clear();
                            return true;
                        }
                    }
                }
            }
            return false;
        }

        public class Table
        {
            private int startRow;
            private int startColom;
            private int endRow;
            private int endColom;
            private Chess startPiece;
            private Chess endPiece;

            public Table(int startRow, int startColom, int endRow, int endColom, Chess startPiece, Chess endPiece)
            {
                this.startRow = startRow;
                this.startColom = startColom;
                this.endRow = endRow;
                this.endColom = endColom;
                this.startPiece = startPiece;
                this.endPiece = endPiece;
            }

            public int GetStartRow()
            {
                return this.startRow;
            }

            public int GetStartColom()
            {
                return this.startColom;
            }

            public int GetEndRow()
            {
                return this.endRow;
            }

            public int GetEndColom()
            {
                return this.endColom;
            }

            public Chess GetStartPiece()
            {
                return this.startPiece;
            }

            public Chess GetEndPiece()
            {
                return this.endPiece;
            }

            //public int GetRound() { return this.round; }
        }

        public class Var
        {
            public static int temp = 0;
            public static List<Table> tableList = new List<Table>();
            public static bool reallyMove = false;
            public static int moveTimes = 0;
        }

        public static void MoveTheChess(Board board)
        {
            //保存每一次的起点和终点.
            SaveEachTable(board.GetFirstInput()[0], board.GetFirstInput()[1], board.GetSecondInput()[0], board.GetSecondInput()[1], board.GetChess(board.GetFirstInput()[0], board.GetFirstInput()[1]), board.GetChess(board.GetSecondInput()[0], board.GetSecondInput()[1]));
            //移动
            board.SetChess(board.GetSecondInput()[0], board.GetSecondInput()[1], board.GetChess(board.GetFirstInput()[0], board.GetFirstInput()[1]));
            board.SetChess(board.GetFirstInput()[0], board.GetFirstInput()[1], new Blank("White"));
            Var.reallyMove = true;
            Var.moveTimes++;
            //还原棋盘 消除蓝色
            ResetBoardToDefaultColor(board);
        }

        public static void SaveEachTable(int startRow, int startColom, int endRow, int endColom, Chess startPiece, Chess endPiece)
        {
            Var.tableList.Add(new Table(startRow, startColom, endRow, endColom, startPiece, endPiece));
        }

        public static void Back(Board board)
        {
            Table table = Var.tableList[Var.moveTimes - 1];
            //还原第一个和第二个, 将刚才拷贝的引用赋值给他们.
            board.SetChess(table.GetStartRow(), table.GetStartColom(), table.GetStartPiece());
            board.SetChess(table.GetEndRow(), table.GetEndColom(), table.GetEndPiece());
            //回合-1倒回悔棋的人
            Controller.ChangeTurnRoundNums(board, -1);
            ResetBoardToDefaultColor(board);
        }

        public static bool JudeBack(Board board)
        {
            if (Var.temp == board.GetTurnRoundNums())
            {   //可以悔
                return false;
            }
            else
            {   //不可以悔
                return true;
            }
        }
    }
}