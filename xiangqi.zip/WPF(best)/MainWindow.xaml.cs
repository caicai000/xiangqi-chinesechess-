﻿using ChineseChess;
using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using static ChineseChess.Controller;

namespace XQ
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private readonly Board board = new Board();

        //private Gameplayer gameplayer = new Gameplayer();
        private GameState gameState = new GameState();

        public int XQRow
        {
            get { return (int)GetValue(XQRowProperty); }
            set { SetValue(XQRowProperty, value); }
        }

        // Using a DependencyProperty as the backing store for XQrow.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty XQRowProperty =
            DependencyProperty.Register("XQRow", typeof(int), typeof(Button), new PropertyMetadata(0));

        public int XQCol
        {
            get { return (int)GetValue(XQColProperty); }
            set { SetValue(XQColProperty, value); }
        }

        // Using a DependencyProperty as the backing store for XQrow.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty XQColProperty =
            DependencyProperty.Register("XQCol", typeof(int), typeof(Button), new PropertyMetadata(0));

        //游戏状态
        public enum GameState
        {
            FirstSelect,
            SecondSelect,
            GameOver
        }

        //改变游戏状态
        public void ChangeState(GameState newState)
        {
            gameState = newState;
        }

        public void CreateGrid()
        {
            //设置棋盘背景图片
            ImageBrush gridBackgroundImage = new ImageBrush
            {
                ImageSource = new BitmapImage(new Uri("image/bg.png", UriKind.Relative))
            };
            grid.Background = gridBackgroundImage;
            //将棋盘分成10*9
            for (int num = 0; num < 10; num++)
            {
                if (num < 9)
                {
                    ColumnDefinition colDef = new ColumnDefinition();
                    grid.ColumnDefinitions.Add(colDef);
                    colDef.Width = new GridLength(1, GridUnitType.Star);
                }
                RowDefinition rowDef = new RowDefinition();
                grid.RowDefinitions.Add(rowDef);
                rowDef.Height = new GridLength(1, GridUnitType.Star);
            }
        }

        private void DrawGrid()
        {
            for (int row = 0; row < 10; row++)
            {
                for (int col = 0; col < 9; col++)
                {
                    //生成棋类对象并设置宽、高、边框
                    Button btn = new Button
                    {
                        Width = 60,
                        Height = 60,
                        BorderThickness = new Thickness(0)//消除边框
                    };
                    //设置棋子背景
                    ImageBrush backgroundImgae = new ImageBrush();
                    backgroundImgae.ImageSource = board.GetChess(row, col).GetName() switch
                    {
                        "车" => board.GetChess(row, col).GetColor().Equals("Red") ? new BitmapImage(new Uri("image/R_Car.png", UriKind.Relative)) : new BitmapImage(new Uri("image/B_Car.png", UriKind.Relative)),
                        "马" => board.GetChess(row, col).GetColor().Equals("Red") ? new BitmapImage(new Uri("image/R_Horse.png", UriKind.Relative)) : new BitmapImage(new Uri("image/B_Horse.png", UriKind.Relative)),
                        "象" => board.GetChess(row, col).GetColor().Equals("Red") ? new BitmapImage(new Uri("image/R_Elephant.png", UriKind.Relative)) : new BitmapImage(new Uri("image/B_Elephant.png", UriKind.Relative)),
                        "士" => board.GetChess(row, col).GetColor().Equals("Red") ? new BitmapImage(new Uri("image/R_Bishop.png", UriKind.Relative)) : new BitmapImage(new Uri("image/B_Bishop.png", UriKind.Relative)),
                        "炮" => board.GetChess(row, col).GetColor().Equals("Red") ? new BitmapImage(new Uri("image/R_Canon.png", UriKind.Relative)) : new BitmapImage(new Uri("image/B_Canon.png", UriKind.Relative)),
                        "帅" => new BitmapImage(new Uri("image/R_King.png", UriKind.Relative)),
                        "将" => new BitmapImage(new Uri("image/B_King.png", UriKind.Relative)),
                        "兵" => new BitmapImage(new Uri("image/R_Pawn.png", UriKind.Relative)),
                        _ => new BitmapImage(new Uri("image/B_Pawn.png", UriKind.Relative)),
                    };
                    btn.Background = backgroundImgae;

                    //不是棋子则设置为透明
                    if (board.GetChess(row, col).GetDefaultColor().Equals("White"))
                    {
                        btn.Background = Brushes.Transparent;
                    }
                    //如果一个棋子存在于另一个棋子的可移动路径 则改变它的背景
                    if (board.GetChess(row, col).GetColor().Equals("Blue"))
                    {
                        backgroundImgae.ImageSource = board.GetChess(row, col).GetName() switch
                        {
                            "车" => board.GetChess(row, col).GetDefaultColor().Equals("Red") ? new BitmapImage(new Uri("image/R_Carblue.png", UriKind.Relative)) : new BitmapImage(new Uri("image/B_Carblue.png", UriKind.Relative)),
                            "马" => board.GetChess(row, col).GetDefaultColor().Equals("Red") ? new BitmapImage(new Uri("image/R_Horseblue.png", UriKind.Relative)) : new BitmapImage(new Uri("image/B_Horseblue.png", UriKind.Relative)),
                            "象" => board.GetChess(row, col).GetDefaultColor().Equals("Red") ? new BitmapImage(new Uri("image/R_Elephantblue.png", UriKind.Relative)) : new BitmapImage(new Uri("image/B_Elephantblue.png", UriKind.Relative)),
                            "士" => board.GetChess(row, col).GetDefaultColor().Equals("Red") ? new BitmapImage(new Uri("image/R_Bishopblue.png", UriKind.Relative)) : new BitmapImage(new Uri("image/B_Bishopblue.png", UriKind.Relative)),
                            "炮" => board.GetChess(row, col).GetDefaultColor().Equals("Red") ? new BitmapImage(new Uri("image/R_Canonblue.png", UriKind.Relative)) : new BitmapImage(new Uri("image/B_Canonblue.png", UriKind.Relative)),
                            "帅" => new BitmapImage(new Uri("image/R_Kingblue.png", UriKind.Relative)),
                            "将" => new BitmapImage(new Uri("image/B_Kingblue.png", UriKind.Relative)),
                            "兵" => new BitmapImage(new Uri("image/R_Pawnblue.png", UriKind.Relative)),
                            "卒" => new BitmapImage(new Uri("image/B_Pawnblue.png", UriKind.Relative)),
                            _ => new BitmapImage(new Uri("image/1.png", UriKind.Relative)),
                        };
                        btn.Background = backgroundImgae;
                    }
                    //点击事件
                    btn.Click += new RoutedEventHandler(this.Button_Click);
                    //给依赖属性设置值
                    btn.SetValue(XQRowProperty, row);
                    btn.SetValue(XQColProperty, col);
                    //把按钮放到Grid对应的点位（row, col）
                    Grid.SetRow(btn, row);
                    Grid.SetColumn(btn, col);
                    grid.Children.Add(btn);
                }
            }
            //根据游戏状态在提示栏输出相应信息
            switch (gameState)
            {
                case GameState.FirstSelect:
                    gamestatetext.Text = "Select Chess";
                    break;

                case GameState.SecondSelect:
                    gamestatetext.Text = "Select Place";
                    break;

                case GameState.GameOver:
                    gamestatetext.Text = "GameOver";
                    MessageBox.Show($"Gameover!!! {board.GetTurnRound()}player is winner.");
                    break;
            }
        }

        //棋类按钮触发事件
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            int btnRow = (int)((Button)sender).GetValue(XQRowProperty);
            int btnCol = (int)((Button)sender).GetValue(XQColProperty);
            //传递被选择按钮的坐标
            HandleClick(btnRow, btnCol);
        }

        private void HandleClick(int btnRow, int btnCol)
        {
            //获取点击按钮的坐标并根据游戏状态进行相应的流程
            switch (gameState)
            {
                case GameState.FirstSelect:

                    Controller.ChangeTurnRoundNums(board, 1);
                    Var.temp = board.GetTurnRoundNums();
                    Var.reallyMove = false;
                    board.SetFirstInput(new int[] { btnRow, btnCol });
                    //判断是否选择正确颜色棋子 不是则回合数-1重新开始
                    if (Controller.ChooseATurnRoundColorChess(board, "firstInput"))
                    {
                        Controller.SetThePosiibleMovePointList(board, "firstInput");

                        ChangeState(GameState.SecondSelect);
                    }
                    else
                    {
                        Controller.ChangeTurnRoundNums(board, -1);
                    }

                    break;

                case GameState.SecondSelect:

                    board.SetSecondInput(new int[] { btnRow, btnCol });
                    //判断选择的点是否为可移动点
                    if (Controller.ChooseBluePoints(board))
                    {
                        if (Controller.TheGeneralIsGongingToBeAte(board))
                        {
                            ChangeState(GameState.GameOver);
                        }
                        else
                        {
                            ChangeState(GameState.FirstSelect);
                        }

                        Controller.MoveTheChess(board);
                        if (gameState != GameState.GameOver)
                        {
                            Round.Text = $"Round {board.GetTurnRoundNums() + 1}";
                        }
                        ToolTips();
                    }
                    //判断选择的是否为同阵营其他棋子
                    else if (Controller.ChooseATurnRoundColorChess(board, "secondInput"))
                    {
                        board.SetFirstInput(new int[] { btnRow, btnCol });
                        Controller.SetThePosiibleMovePointList(board, "secondInput");
                        ChangeState(GameState.SecondSelect);
                    }
                    break;

                case GameState.GameOver:
                    MessageBox.Show($"Gameover!!! {board.GetTurnRound()}player is winner.");
                    break;
            }

            grid.Children.Clear();
            DrawGrid();
            //如果某第二步移动完有棋子可以将军则提示将军
            if (Controller.IsValid(board) && Var.reallyMove)
            {
                MessageBox.Show("将军！");
            }
        }

        //设置提示栏
        private void ToolTips()
        {
            if (gameState != GameState.GameOver)
            {
                if (board.GetTurnRound().Equals("Black"))
                {
                    player.Text = "Red Player";
                    player.Foreground = Brushes.Red;
                    gamestatetext.Foreground = Brushes.Red;
                    Round.Background = Brushes.Red;
                }
                else
                {
                    player.Text = "Black Player";
                    player.Foreground = Brushes.Black;
                    gamestatetext.Foreground = Brushes.Black;
                    Round.Background = Brushes.Black;
                }
            }
        }

        //悔棋按钮事件
        private void Regret_Click(object sender, RoutedEventArgs e)
        {
            if (!Controller.JudeBack(board) && Var.reallyMove)
            {
                //棋子复位并更新提示栏
                Controller.Back(board);
                ToolTips();
                Round.Text = $"Round {board.GetTurnRoundNums() + 1}";
                grid.Children.Clear();
                DrawGrid();
            }
            else
            {
                MessageBox.Show("Please using regret after you move");
            }
        }

        //开始按钮事件
        private void Start_Click(object sender, RoutedEventArgs e)
        {
            Var.tableList.Clear();
            Var.moveTimes = 0;
            string text = Convert.ToString(start.Content);
            if (text == "Start")
            {
                //点击start后 按钮文字会更改成restart
                DrawGrid();
                start.Content = "Restart";
                start.Margin = new Thickness(10, 101, 10, 529);
            }

            if (text == "Restart")
            {
                //重新开始 重置棋盘并更新提示栏
                Controller.Restart(board);
                ChangeState(GameState.FirstSelect);
                Round.Text = $"Round {board.GetTurnRoundNums() + 1}";
                Round.Background = Brushes.Red;
                player.Text = "Red Player";
                player.Foreground = Brushes.Red;
                gamestatetext.Foreground = Brushes.Red;
                grid.Children.Clear();  //需要在这里把model里的棋盘重置
                DrawGrid();
            }
            //如果没点击开始 则棋子不可见
            back.Visibility = Visibility.Visible;
            giveup.Visibility = Visibility.Visible;
            player.Visibility = Visibility.Visible;
            gamestatetext.Visibility = Visibility.Visible;
            Round.Visibility = Visibility.Visible;
        }

        //投降按钮触发事件
        private void Giveup_Click(object sender, RoutedEventArgs e)
        {
            ChangeState(GameState.GameOver);
            MessageBox.Show($"Gameover!!! {board.GetTurnRound()}player is winner.");
        }

        private void start_MouseMove(object sender, System.Windows.Input.MouseEventArgs e)
        {
            start.Background = Brushes.AliceBlue;
        }

        private void start_MouseLeave(object sender, System.Windows.Input.MouseEventArgs e)
        {
            start.Background = Brushes.Green;
        }

        private void back_MouseLeave(object sender, System.Windows.Input.MouseEventArgs e)
        {
            back.Background = Brushes.Red;
        }

        private void giveup_MouseLeave(object sender, System.Windows.Input.MouseEventArgs e)
        {
            giveup.Background = Brushes.Blue;
        }

        private void back_MouseMove(object sender, System.Windows.Input.MouseEventArgs e)
        {
            back.Background = Brushes.AliceBlue;
        }

        private void giveup_MouseMove(object sender, System.Windows.Input.MouseEventArgs e)
        {
            giveup.Background = Brushes.AliceBlue;
        }

        //游戏主函数
        public MainWindow()
        {
            InitializeComponent();
            CreateGrid();
        }
    }
}